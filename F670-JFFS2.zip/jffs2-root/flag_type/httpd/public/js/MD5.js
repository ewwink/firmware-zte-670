
var hexchar = "0123456789abcdef";
function rhexfunc(num)
{
str = "";
for(j = 0; j <= 3; j++)
str += hexchar.charAt((num >> (j * 8 + 4)) & 0x0F) + hexchar.charAt((num >> (j * 8)) & 0x0F);
return str;
}
function str2blksfunc_MD5(str)
{
numblk = ((str.length + 8) >> 6) + 1;
blks = new Array(numblk * 16);
for(i = 0; i < numblk * 16; i++) blks[i] = 0;
for(i = 0; i < str.length; i++)
blks[i >> 2] |= str.charCodeAt(i) << ((i % 4) * 8);
blks[i >> 2] |= 0x80 << ((i % 4) * 8);
blks[numblk * 16 - 2] = str.length * 8;
return blks;
}
function addfunc(x, y)
{
var lsw = (x & 0xFFFF) + (y & 0xFFFF);
var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
return (msw << 16) | (lsw & 0xFFFF);
}
function rolfunc(num, cnt)
{
return (num << cnt) | (num >>> (32 - cnt));
}
function cmnfunc(q, a, b, x, s, t)
{
return addfunc(rolfunc(addfunc(addfunc(a, q), addfunc(x, t)), s), b);
}
function fffunc(a, b, c, d, x, s, t)
{
return cmnfunc((b & c) | ((~b) & d), a, b, x, s, t);
}
function ggfunc(a, b, c, d, x, s, t)
{
return cmnfunc((b & d) | (c & (~d)), a, b, x, s, t);
}
function hhfunc(a, b, c, d, x, s, t)
{
return cmnfunc(b ^ c ^ d, a, b, x, s, t);
}
function iifunc(a, b, c, d, x, s, t)
{
return cmnfunc(c ^ (b | (~d)), a, b, x, s, t);
}
function MD5(str)
{
x = str2blksfunc_MD5(str);
var m = 1732584193;
var n = -271733879;
var g = -1732584194;
var h = 271733878;
for(i = 0; i < x.length; i += 16)
{
var olda = m;
var oldb = n;
var oldc = g;
var oldd = h;
m = fffunc(m, n, g, h, x[i+ 0], 7 , -680876936);
h = fffunc(h, m, n, g, x[i+ 1], 12, -389564586);
g = fffunc(g, h, m, n, x[i+ 2], 17, 606105819);
n = fffunc(n, g, h, m, x[i+ 3], 22, -1044525330);
m = fffunc(m, n, g, h, x[i+ 4], 7 , -176418897);
h = fffunc(h, m, n, g, x[i+ 5], 12, 1200080426);
g = fffunc(g, h, m, n, x[i+ 6], 17, -1473231341);
n = fffunc(n, g, h, m, x[i+ 7], 22, -45705983);
m = fffunc(m, n, g, h, x[i+ 8], 7 , 1770035416);
h = fffunc(h, m, n, g, x[i+ 9], 12, -1958414417);
g = fffunc(g, h, m, n, x[i+10], 17, -42063);
n = fffunc(n, g, h, m, x[i+11], 22, -1990404162);
m = fffunc(m, n, g, h, x[i+12], 7 , 1804603682);
h = fffunc(h, m, n, g, x[i+13], 12, -40341101);
g = fffunc(g, h, m, n, x[i+14], 17, -1502002290);
n = fffunc(n, g, h, m, x[i+15], 22, 1236535329);
m = ggfunc(m, n, g, h, x[i+ 1], 5 , -165796510);
h = ggfunc(h, m, n, g, x[i+ 6], 9 , -1069501632);
g = ggfunc(g, h, m, n, x[i+11], 14, 643717713);
n = ggfunc(n, g, h, m, x[i+ 0], 20, -373897302);
m = ggfunc(m, n, g, h, x[i+ 5], 5 , -701558691);
h = ggfunc(h, m, n, g, x[i+10], 9 , 38016083);
g = ggfunc(g, h, m, n, x[i+15], 14, -660478335);
n = ggfunc(n, g, h, m, x[i+ 4], 20, -405537848);
m = ggfunc(m, n, g, h, x[i+ 9], 5 , 568446438);
h = ggfunc(h, m, n, g, x[i+14], 9 , -1019803690);
g = ggfunc(g, h, m, n, x[i+ 3], 14, -187363961);
n = ggfunc(n, g, h, m, x[i+ 8], 20, 1163531501);
m = ggfunc(m, n, g, h, x[i+13], 5 , -1444681467);
h = ggfunc(h, m, n, g, x[i+ 2], 9 , -51403784);
g = ggfunc(g, h, m, n, x[i+ 7], 14, 1735328473);
n = ggfunc(n, g, h, m, x[i+12], 20, -1926607734);
m = hhfunc(m, n, g, h, x[i+ 5], 4 , -378558);
h = hhfunc(h, m, n, g, x[i+ 8], 11, -2022574463);
g = hhfunc(g, h, m, n, x[i+11], 16, 1839030562);
n = hhfunc(n, g, h, m, x[i+14], 23, -35309556);
m = hhfunc(m, n, g, h, x[i+ 1], 4 , -1530992060);
h = hhfunc(h, m, n, g, x[i+ 4], 11, 1272893353);
g = hhfunc(g, h, m, n, x[i+ 7], 16, -155497632);
n = hhfunc(n, g, h, m, x[i+10], 23, -1094730640);
m = hhfunc(m, n, g, h, x[i+13], 4 , 681279174);
h = hhfunc(h, m, n, g, x[i+ 0], 11, -358537222);
g = hhfunc(g, h, m, n, x[i+ 3], 16, -722521979);
n = hhfunc(n, g, h, m, x[i+ 6], 23, 76029189);
m = hhfunc(m, n, g, h, x[i+ 9], 4 , -640364487);
h = hhfunc(h, m, n, g, x[i+12], 11, -421815835);
g = hhfunc(g, h, m, n, x[i+15], 16, 530742520);
n = hhfunc(n, g, h, m, x[i+ 2], 23, -995338651);
m = iifunc(m, n, g, h, x[i+ 0], 6 , -198630844);
h = iifunc(h, m, n, g, x[i+ 7], 10, 1126891415);
g = iifunc(g, h, m, n, x[i+14], 15, -1416354905);
n = iifunc(n, g, h, m, x[i+ 5], 21, -57434055);
m = iifunc(m, n, g, h, x[i+12], 6 , 1700485571);
h = iifunc(h, m, n, g, x[i+ 3], 10, -1894986606);
g = iifunc(g, h, m, n, x[i+10], 15, -1051523);
n = iifunc(n, g, h, m, x[i+ 1], 21, -2054922799);
m = iifunc(m, n, g, h, x[i+ 8], 6 , 1873313359);
h = iifunc(h, m, n, g, x[i+15], 10, -30611744);
g = iifunc(g, h, m, n, x[i+ 6], 15, -1560198380);
n = iifunc(n, g, h, m, x[i+13], 21, 1309151649);
m = iifunc(m, n, g, h, x[i+ 4], 6 , -145523070);
h = iifunc(h, m, n, g, x[i+11], 10, -1120210379);
g = iifunc(g, h, m, n, x[i+ 2], 15, 718787259);
n = iifunc(n, g, h, m, x[i+ 9], 21, -343485551);
m = addfunc(m, olda);
n = addfunc(n, oldb);
g = addfunc(g, oldc);
h = addfunc(h, oldd);
}
return rhexfunc(m) + rhexfunc(n) + rhexfunc(g) + rhexfunc(h);
}