var pubKey = "-----BEGIN PUBLIC KEY-----\n\
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAodPTerkUVCYmv28SOfRV\n\
7UKHVujx/HjCUTAWy9l0L5H0JV0LfDudTdMNPEKloZsNam3YrtEnq6jqMLJV4ASb\n\
1d6axmIgJ636wyTUS99gj4BKs6bQSTUSE8h/QkUYv4gEIt3saMS0pZpd90y6+B/9\n\
hZxZE/RKU8e+zgRqp1/762TB7vcjtjOwXRDEL0w71Jk9i8VUQ59MR1Uj5E8X3WIc\n\
fYSK5RWBkMhfaTRM6ozS9Bqhi40xlSOb3GBxCmliCifOJNLoO9kFoWgAIw5hkSIb\n\
GH+4Csop9Uy8VvmmB+B3ubFLN35qIa5OG5+SDXn4L7FeAA5lRiGxRi8tsWrtew8w\n\
nwIDAQAB\n\
-----END PUBLIC KEY-----";
function EncodeKey(key,iv)
{
var str = key + "+" + iv;
var encrypt = new JSEncrypt();
encrypt.setPublicKey(pubKey);
var encrypted = encrypt.encrypt(str);
return encrypted.toString();
}
function EncodePara(data,key,iv){
var key  = CryptoJS.SHA256(key);
var iv   = CryptoJS.SHA256(iv);
var encrypted =CryptoJS.AES.encrypt(data,key,
{
iv:iv,
mode:CryptoJS.mode.CBC,
padding:CryptoJS.pad.ZeroPadding
});
return encrypted.toString();
}
function DecodePara(encrypted,key,iv){
var key  = CryptoJS.SHA256(key);
var iv   = CryptoJS.SHA256(iv);
var decrypted =CryptoJS.AES.decrypt(encrypted,key,
{
iv:iv,
mode:CryptoJS.mode.CBC,
padding:CryptoJS.pad.ZeroPadding
});
return decrypted.toString(CryptoJS.enc.Utf8);
}
